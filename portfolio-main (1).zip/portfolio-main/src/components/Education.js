import React from "react";
import './education.css'
const Education=()=>{
    return(
        <div className="Education">
<div>
<h5>B.Tech in Computer Engineering</h5>
Marwadi University, Rajkot , Gujrat <br/>
Expected Graduation: July , 2026  <br/>
<h5> Relevant Coursework</h5><ul><li>Data Structures and Algorithms</li><li> Database Management Systems</li> <li>Operating Systems</li><li>Computer Networks</li> <li>Web Development</li> 
</ul> 
<h5>Senior Secondary Education (Class 12th)</h5> 
Madhav Public School, GorakhPur , Uttar Pradesh <br/>
Year of Graduation: 2021 <br/>
 Major Subjects: Physics, Chemistry, Mathematics<br/>
 Percentage/Grade: 70.2%<br/>

 <h5>Secondary Education (Class 10th)</h5> 
Gyanda International School ,  GopalGanj , Bihar <br/>
Year of Graduation: 2019  <br/>
Percentage/Grade: 76.6%
</div>


        

        </div>
    )
}
export default Education