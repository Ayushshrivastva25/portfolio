import React from 'react';
import Project1 from './Project1';
import Project2 from './Project2';
import Project3 from './Project3';
const Project=()=>{
    return(
        <div>
          
          <Project1/>
        <hr/>
        <hr/>
          <Project2/>
          <hr/>
            <Project3/>
        </div>
    )

}
export default Project